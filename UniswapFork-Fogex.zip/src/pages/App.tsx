import React, { Suspense, useState } from 'react'
import { Route, Switch, useHistory } from 'react-router-dom'
import styled from 'styled-components'
import GoogleAnalyticsReporter from '../components/analytics/GoogleAnalyticsReporter'
import AddressClaimModal from '../components/claim/AddressClaimModal'
import Header from '../components/Header'
import Polling from '../components/Header/Polling'
import URLWarning from '../components/Header/URLWarning'
import Popups from '../components/Popups'
import Web3ReactManager from '../components/Web3ReactManager'
import { ApplicationModal } from '../state/application/actions'
import { useModalOpen, useToggleModal } from '../state/application/hooks'
import DarkModeQueryParamReader from '../theme/DarkModeQueryParamReader'
import AddLiquidity from './AddLiquidity'
import {
  RedirectDuplicateTokenIds,
  RedirectOldAddLiquidityPathStructure,
  RedirectToAddLiquidity
} from './AddLiquidity/redirects'
import Earn from './Earn'
import Manage from './Earn/Manage'
import MigrateV1 from './MigrateV1'
import MigrateV1Exchange from './MigrateV1/MigrateV1Exchange'
import RemoveV1Exchange from './MigrateV1/RemoveV1Exchange'
import Pool from './Pool'
import PoolFinder from './PoolFinder'
import RemoveLiquidity from './RemoveLiquidity'
import { RedirectOldRemoveLiquidityPathStructure } from './RemoveLiquidity/redirects'
import Swap from './Swap'
import { OpenClaimAddressModalAndRedirectToSwap, RedirectPathToSwapOnly, RedirectToSwap } from './Swap/redirects'

import Vote from './Vote'
import VotePage from './Vote/VotePage'

import Home from './Home'

import smallBg1 from '../assets/images/bac3.png'
import smallBg2 from '../assets/images/bac2.png'

import logo1 from '../assets/images/logos/logo-1.png';
import logo2 from '../assets/images/logos/logo-2.png';
import logo3 from '../assets/images/logos/logo-3.png';
import logo4 from '../assets/images/logos/logo-4.png';

const AppWrapper = styled.div`
  display: flex;
  flex-flow: column;
  align-items: flex-start;
  overflow-x: hidden;
`

const HeaderWrapper = styled.div`
  ${({ theme }) => theme.flexRowNoWrap}
  width: 100%;
  justify-content: space-between;
`

const BodyWrapper = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  padding-top: 100px;
  align-items: center;
  flex: 1;
  overflow-y: auto;
  overflow-x: hidden;
  z-index: 10;

  ${({ theme }) => theme.mediaWidth.upToSmall`
    padding: 16px;
    padding-top: 2rem;
  `};

  z-index: 1;
`

const LogoGroup = styled.div`
  display: flex;
`

const Marginer = styled.div`
  margin-top: 5rem;
`

const CBody = styled.div`
  bottom: 20px;
  position: absolute;
  z-index: -9;
`

const CLabel = styled.span`
  color: #000;
  text-align: center;
  margin: 0 auto;
  display: block;
`

const BgPiece1 = styled.img`
  position: absolute;
  bottom: 0;
  opacity: 0.6;
`

const BgPiece2 = styled.img`
  position: absolute;
  left: -100px;
  opacity: 0.6;
`

const Sidebar = styled.div`
  left: 0;
  top: 30%;
  position: absolute;
`

const MenuText = styled.div`
  background: linear-gradient(to right, #f5a8db, #ef8aca, #fff);
  font-weight: bold;
  font-size: 25px;
  padding: 10px 60px;
  margin: 30px 0;
`

const MenuBg = styled.div`
  cursor: pointer;
  display: block;
  ${({ theme }) => theme.mediaWidth.upToMedium`
    display: none;
  `};
`

function TopLevelModals() {
  const open = useModalOpen(ApplicationModal.ADDRESS_CLAIM)
  const toggle = useToggleModal(ApplicationModal.ADDRESS_CLAIM)
  return <AddressClaimModal isOpen={open} onDismiss={toggle} />
}

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>("swap");
  const history = useHistory();

  return (
    <Suspense fallback={null}>
      <Route component={GoogleAnalyticsReporter} />
      <Route component={DarkModeQueryParamReader} />
      <AppWrapper>
        <BgPiece2 width={'200px'} src={smallBg2} alt="bg2" />
        <URLWarning />
        <HeaderWrapper>
          <Header />
        </HeaderWrapper>
        <BodyWrapper>
          <Sidebar>
            <MenuBg>
              <MenuText style={{ background: currentTab === 'swap' ? 'linear-gradient(to right, #f5a8db, #ef8aca, #fff)': 'none'}} onClick={() =>{setCurrentTab('swap'); history.push('/swap')}}>SWAP</MenuText>
              <MenuText style={{ background: currentTab === 'pool' ? 'linear-gradient(to right, #f5a8db, #ef8aca, #fff)': 'none'}} onClick={() =>{setCurrentTab('pool'); history.push('/pool')}}>POOL</MenuText>
              <MenuText style={{ background: currentTab === 'fogle' ? 'linear-gradient(to right, #f5a8db, #ef8aca, #fff)': 'none'}} onClick={() =>{setCurrentTab('fogle'); history.push('/uni')}}>FOGLE</MenuText>
            </MenuBg>
          </Sidebar>
          <Popups />
          <Polling />
          <TopLevelModals />
          <Web3ReactManager>
            <Switch>
              <Route exact strict path="/home" component={Home} />
              <Route exact strict path="/swap" component={Swap} />
              <Route exact strict path="/claim" component={OpenClaimAddressModalAndRedirectToSwap} />
              <Route exact strict path="/swap/:outputCurrency" component={RedirectToSwap} />
              <Route exact strict path="/send" component={RedirectPathToSwapOnly} />
              <Route exact strict path="/find" component={PoolFinder} />
              <Route exact strict path="/pool" component={Pool} />
              <Route exact strict path="/uni" component={Earn} />
              <Route exact strict path="/vote" component={Vote} />
              <Route exact strict path="/create" component={RedirectToAddLiquidity} />
              <Route exact path="/add" component={AddLiquidity} />
              <Route exact path="/add/:currencyIdA" component={RedirectOldAddLiquidityPathStructure} />
              <Route exact path="/add/:currencyIdA/:currencyIdB" component={RedirectDuplicateTokenIds} />
              <Route exact path="/create" component={AddLiquidity} />
              <Route exact path="/create/:currencyIdA" component={RedirectOldAddLiquidityPathStructure} />
              <Route exact path="/create/:currencyIdA/:currencyIdB" component={RedirectDuplicateTokenIds} />
              <Route exact strict path="/remove/v1/:address" component={RemoveV1Exchange} />
              <Route exact strict path="/remove/:tokens" component={RedirectOldRemoveLiquidityPathStructure} />
              <Route exact strict path="/remove/:currencyIdA/:currencyIdB" component={RemoveLiquidity} />
              <Route exact strict path="/migrate/v1" component={MigrateV1} />
              <Route exact strict path="/migrate/v1/:address" component={MigrateV1Exchange} />
              <Route exact strict path="/uni/:currencyIdA/:currencyIdB" component={Manage} />
              <Route exact strict path="/vote/:id" component={VotePage} />
              <Route component={RedirectPathToSwapOnly} />
            </Switch>
          </Web3ReactManager>
          <CBody>
            <CLabel>Powered by Superpack</CLabel>
            <LogoGroup>
              <img src={logo1} width={'50px'} style={{margin: '20px'}}/>
              <img src={logo2} width={'50px'} style={{margin: '20px'}}/>
              <img src={logo3} width={'50px'} style={{margin: '20px'}}/>
              <img src={logo4} width={'50px'} style={{margin: '20px'}}/>
            </LogoGroup>
          </CBody>
          <Marginer />
        </BodyWrapper>

      </AppWrapper>
      <BgPiece1 width={'350px'} src={smallBg1} alt="bg1" />
    </Suspense>
  )
}
