import React from 'react'
import { AutoColumn } from '../../components/Column'
import styled from 'styled-components'
import { RowBetween } from '../../components/Row'
// import { TYPE, ExternalLink } from '../../theme'
// import { RowBetween, RowFixed } from '../../components/Row'
// import { Link } from 'react-router-dom'

import FogeLogo from '../../assets/images/fogelogo.gif';

const PageWrapper = styled(AutoColumn)``

const TopSection = styled(AutoColumn)`
  max-width: 840px;
  width: 100%;
`

const ALabel = styled.span`
  color: #000;
  text-align: left;
  display: block;
  font-size: 40px;
  font-style: italic;
`

const BLabel = styled.span`
  color: #000;
  text-align: left;
  display: block;
  font-size: 90px;
  font-stretch: expanded;
`

const CLabel = styled.span`
  color: #f4abd8;
  text-align: left;
  display: block;
  font-size: 18px;
`

const DLabel = styled.span`
  color: #000;
  text-align: left;
  display: block;
  font-size: 16px;
`

const BuyButton = styled.div`
  background: linear-gradient(to right, #494949, #3b3b3b, #494949);
  font-weight: bold;
  font-size: 25px;
  padding: 10px 50px;
  margin: 30px 0;
  color: #fff;
  width: 265px;
  margin: 0 auto;
  text-align: center;
`

const SmallButton = styled.div`
  background: linear-gradient(to right, #d7d7d7, #c5c5c5, #d7d7d7);
  font-weight: bold;
  font-size: 18px;
  padding: 10px 20px;
  margin: 10px 0;
  color: #000;
  margin: 0 auto;
  text-align: center;
`

const TwoButtonWrap = styled.div`
  display: flex;
  width: 280px;
  margin: 0 auto;
`

export default function Home() {

  return (
    <PageWrapper gap="lg" justify="center">
      <TopSection gap="md">
        <RowBetween>
          <AutoColumn gap="10px" style={{ width: '100%' }}>
            <ALabel>WELCOME TO</ALabel>
            <BLabel><b>FAT</b>DOGE</BLabel>
            <CLabel>$FOGE - A Charitable Meme Token To Help All Doge</CLabel>
            <DLabel>After all the hype on dog tokens and their insane gains, $FOGE has managed to live an excessive life.</DLabel>
            <DLabel>As a result of having access to an endless amount of food, he has become just a bit... bulky.</DLabel>
            <DLabel>But is there anything to stop him? Will this dog manage to take one more bite? You bet he will! Join us on the feast and watch the doge grow fat.</DLabel>
          </AutoColumn>
          <AutoColumn gap="10px" style={{ width: '100%' }}>
            <img src={FogeLogo} width={350} style={{margin: '0 auto'}}/>
            <BuyButton>BUY $FOGE</BuyButton>
            <TwoButtonWrap>
              <SmallButton>CHART</SmallButton>
              <SmallButton>CONTRACT</SmallButton>
            </TwoButtonWrap>
          </AutoColumn>
        </RowBetween>
      </TopSection>
    </PageWrapper>
  )
}
