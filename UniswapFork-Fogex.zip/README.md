https://fogedex.finance/

Uniswap fork, with custom factory and router contracts, for rinkeby testnet

factory: 0x4483A66586EB1EF3A05CD678171F388cA0C3700A

routerv2: 0x4Df1C5732d455Dd22F2c7563e42A87fEB827D038
